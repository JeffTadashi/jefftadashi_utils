# jefftadashi_utils
My general utilities Python module!

More info to come.